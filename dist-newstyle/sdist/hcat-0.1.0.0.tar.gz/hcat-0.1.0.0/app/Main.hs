module Main where

import HCat (runHCat)

main :: IO ()
main = HCat.runHCat
